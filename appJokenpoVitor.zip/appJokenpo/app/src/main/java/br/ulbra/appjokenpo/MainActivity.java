package br.ulbra.appjokenpo;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    int pontuacaoJogador = 0;
    int pontuacaoApp = 0;
    Button btnReiniciar;
    TextView txtReinicio, txtReinicio2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        btnReiniciar = findViewById(R.id.btnReiniciar);
        txtReinicio = findViewById(R.id.txtResultado1);
        txtReinicio2 = findViewById(R.id.txtResultado2);


        btnReiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reiniciarJogo();
                txtReinicio.setText("O JOGO FOI REINICIADO, PRECIONE NOVAMENTE UMA OPÇÃO!!");
                txtReinicio2.setText("RESULTADO: ???");

            }
        });
    }

    public void selecionadoPedra(View view) {
        this.opcaoSelecionado("pedra");
    }

    public void selecionadoPapel(View view) {
        this.opcaoSelecionado("papel");
    }

    public void selecionadoTesoura(View view) {
        this.opcaoSelecionado("tesoura");
    }


    public void opcaoSelecionado(String opcaoSelecionada) {
        ImageView imgResultado = findViewById(R.id.imgMaquina);
        TextView txtResult = findViewById(R.id.txtResultado1);

        String opcoes[] = {"pedra", "papel", "tesoura"};
        String opcaoApp = opcoes[new Random().nextInt(3)];
        switch (opcaoApp) {
            case "pedra":
                imgResultado.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imgResultado.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imgResultado.setImageResource(R.drawable.tesoura);
                break;
        }
        if ((opcaoApp.equals("tesoura")) && (opcaoSelecionada.equals("papel")) ||
                (opcaoApp.equals("papel")) && (opcaoSelecionada.equals("pedra")) ||
                (opcaoApp.equals("pedra")) && (opcaoSelecionada.equals("tesoura"))) {
            txtResult.setText("RESULTADO: Você PERDEU... :(");
            pontuacaoApp++;
            atualizarPlacar();

        } else if ((opcaoSelecionada.equals("tesoura")) && (opcaoApp.equals("papel")) ||
                (opcaoSelecionada.equals("papel")) && (opcaoApp.equals("pedra")) ||
                (opcaoSelecionada.equals("pedra")) && (opcaoApp.equals("tesoura"))) {
            txtResult.setText("RESULTADO: Você GANHOU!!! ");
            pontuacaoJogador++;
            atualizarPlacar();
        } else {
            txtResult.setText("RESULTADO: Vocês EMPATARAM.");
            atualizarPlacar();

        }

    }

    public void atualizarPlacar() {
        TextView txtPlacar = findViewById(R.id.txtResultado2);
        txtPlacar.setText("Jogador:" + pontuacaoJogador + " - App:" + pontuacaoApp);
    }

    public void reiniciarJogo() {
        atualizarPlacar();
        ImageView imageResultado = findViewById(R.id.imgMaquina);
        imageResultado.setImageResource(android.R.color.transparent);
    }


}