package br.ulbra.appcompra;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    CheckBox chArroz, chLeite, chCarne, chFeijao;

    Button btnTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        chArroz = (CheckBox) findViewById(R.id.chArroz);
        chLeite = (CheckBox) findViewById(R.id.chLeite);
        chCarne = (CheckBox) findViewById(R.id.chCarne);
        chFeijao = (CheckBox) findViewById(R.id.chFeijao);
        btnTotal = (Button) findViewById(R.id.btnTotal);
        DecimalFormat f = new DecimalFormat("0.00");
        btnTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double total = 0;
                if (chArroz.isChecked()) { total += 2.69; }
                if (chLeite.isChecked()) { total += 5.00; }
                if (chCarne.isChecked()) { total += 9.7; }
                if (chFeijao.isChecked()) { total += 2.30; }

                AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
                dialogo.setTitle("Aviso");
                dialogo.setMessage("Valor Total da compra:" + String.valueOf(f.format(total)));
                dialogo.setNeutralButton("Ok", null);
                dialogo.show();
            }
        });

    }
}